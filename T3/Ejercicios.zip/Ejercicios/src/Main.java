public class Main {

    public static void main(String[] args) {
        Ejercicios ejercicios = new Ejercicios();
        ejercicios.ejercicio2();

    }
}
