public class Ejercicio2 {
}
