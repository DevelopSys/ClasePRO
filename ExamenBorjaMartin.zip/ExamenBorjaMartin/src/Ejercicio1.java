public class Ejercicio1 {
    /*
        asdasdasd
     */
}
