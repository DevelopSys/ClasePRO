public class Ejercicio6 {
}
